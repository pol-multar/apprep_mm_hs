Projet Mini-Twitter
Applications R�parties
SI4 Groupe 2
MULTARI Maxime, SIMOND Hugo

==================================
Lancement :
Apr�s avoir lanc� activeMQ, vous trouverez dans le dossier executables deux fichiers :
 - serveur, qui contient le jar executable du serveur
 - client, qui contient le jar executable du client

Pour les lancer : java -jar <nomdujar.jar>

==================================
Fonctionnalit�s :
- Se connecter ( 3 utilisateurs disponibles : user1, user2 et user3. Le mot de passe est : pwd)
- Se deconnecter
- S'abonner � un hashtag (qui sera cr�� si il n'existe pas encore)
- Poster un tweet
- Retweeter un tweet

Toutes les connexion se font par d�faut sur localhost. Si l'on souhaite modifier cela, il faut recompiler le programme.
Vous ne pouvez utiliser que 3 clients maximum, en effet on ne peut se connecter au syst�me deux fois avec le m�me compte.
Si vous ne vous d�connectez pas avec la m�thode de d�connexion, vous ne pourrez plus vous reconnecter sans red�marrer le serveur .

==================================
Architecture :
Le client se connecte au serveur en RMI pour r�cup�rer v�rifier les logins et mot de passe, ainsi que pour poster des tweets et retweeter, cr�er de nouveaux hashtags.
Le serveur a ensuite le role de publisher JMS : c'est lui qui cr�e les topics en fonctions des hastags envoy�s en rmi par le client et envoi les tweets sur ceux-ci.
Le client a le role de consummer JMS : Il re�oit les messages envoy�s sur les topics o� il est abonn�. Lorsqu'un client s'abonne � un topic/hashtag, cela lance un thread qui sera charg� d'attendre tous les tweets qui contiennent le hastag.
Le client n'a acc�s qu'� l'interface TwitterRemote qui expose les m�thodes RMI du serveur.

==================================
Ce qui n'a pas �t� d�velopp� :
-La persistance des tweets n'est pas assur�e.
-Si un abonn� n'est pas connect�, il n'est pas notifi� de l'arriv�e des tweets

